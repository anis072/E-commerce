export const endpoints = {
  MENU :"menu/all",
  CATEGORYBYID: "/menu/",
  product:"/category/"
}
